import sys
class namewasnotfounded(Exception):pass
try:
    studenttxt = open("student.txt", "r")
    students = {line.replace("\n", "").split(":")[0]: tuple(line.replace("\n", "").split(":")[1].split(",")) for line in studenttxt.readlines}
    studenttxt.close()
    argument = sys.argv[2].split(",")
    for name in argument:
        if not(name in students.keys()):
            raise namewasnotfounded("{name} wasnt founded")
        print(("{name} : {students[name][0]} , {students[name][1]}"))
except IOError  :
    print("ERROR: IOError students.txt wasnt founded")
except namewasnotfounded as error:
    print("ERROR: namewasnotfounded  {error}")